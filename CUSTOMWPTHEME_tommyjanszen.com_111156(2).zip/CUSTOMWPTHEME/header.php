<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta name="viewport" content="width=device-width" />
  <title><?php wp_title( ' | ', true, 'right' ); ?></title>
  <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/style-base.css" />
  <?php wp_head(); ?>
  <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>" />

<base href="http://tommyjanszen.com/">

		
		<meta charset="utf=8">
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/reset.css">
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css">
		<link rel="stylesheet prefetch" href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css">
		
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css"></head>

	<body>

		<div class="content-wrapper" style="overflow: visible;">
			
			<div class="nav">
				<span class="nav-name"><a href="http://tommyjanszen.com/index.html">@tommyjanszen</a></span>
			</div>

			<div class="main-section">
				<span class="main-title">
					blog
				</span>
			</div>
			
			<div class="blog-content" style="overflow: visible;">
<?php $GLOBALS["type"] = "insidesidebar-right";?>